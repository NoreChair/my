/*
Copyright Disney Enterprises, Inc. All rights reserved.

This license governs use of the accompanying software. If you use the software, you
accept this license. If you do not accept the license, do not use the software.

1. Definitions
The terms "reproduce," "reproduction," "derivative works," and "distribution" have
the same meaning here as under U.S. copyright law. A "contribution" is the original
software, or any additions or changes to the software. A "contributor" is any person
that distributes its contribution under this license. "Licensed patents" are a
contributor's patent claims that read directly on its contribution.

2. Grant of Rights
(A) Copyright Grant- Subject to the terms of this license, including the license
conditions and limitations in section 3, each contributor grants you a non-exclusive,
worldwide, royalty-free copyright license to reproduce its contribution, prepare
derivative works of its contribution, and distribute its contribution or any derivative
works that you create.
(B) Patent Grant- Subject to the terms of this license, including the license
conditions and limitations in section 3, each contributor grants you a non-exclusive,
worldwide, royalty-free license under its licensed patents to make, have made,
use, sell, offer for sale, import, and/or otherwise dispose of its contribution in the
software or derivative works of the contribution in the software.

3. Conditions and Limitations
(A) No Trademark License- This license does not grant you rights to use any
contributors' name, logo, or trademarks.
(B) If you bring a patent claim against any contributor over patents that you claim
are infringed by the software, your patent license from such contributor to the
software ends automatically.
(C) If you distribute any portion of the software, you must retain all copyright,
patent, trademark, and attribution notices that are present in the software.
(D) If you distribute any portion of the software in source code form, you may do
so only under this license by including a complete copy of this license with your
distribution. If you distribute any portion of the software in compiled or object code
form, you may only do so under a license that complies with this license.
(E) The software is licensed "as-is." You bear the risk of using it. The contributors
give no express warranties, guarantees or conditions. You may have additional
consumer rights under your local laws which this license cannot change.
To the extent permitted under your local laws, the contributors exclude the
implied warranties of merchantability, fitness for a particular purpose and non-
infringement.
*/

#include <QHBoxLayout>
#include <QLabel>
#include <QColorDialog>
#include <QApplication>
#include "ColorVarWidget.h"

QColorDialog* ColorVarWidget::_colorDialog = 0;

ColorVarWidget::ColorVarWidget(QString name, float r, float g, float b)
{
	QHBoxLayout *layout = new QHBoxLayout;

	// add the label with this parameter's name
	QLabel* label = new QLabel( name );
    QFont font = label->font();
    font.setBold( true );
    label->setFont( font );
	layout->addWidget( label );


	// create the button that displays the color
	colorButton = new ColorVarButton( );
	colorButton->setFixedWidth( 65 );
	colorButton->setFixedHeight( 22 );
	connect(colorButton, SIGNAL(clicked()), this, SLOT(showColorChanger()));
	layout->addWidget( colorButton );
        connect(colorButton, SIGNAL(setToDefault()), this, SLOT(setToDefault()));

	// set the color to the input
	color.setRgbF( r, g, b );
        defaultColor = color;
	resetButtonColor();
	

	// layout stuff
	setContentsMargins( 0, 0, 0, 0 );
	layout->setMargin( 1 );
	setSizePolicy( QSizePolicy::Preferred, QSizePolicy::Fixed );

	setLayout(layout);
}



ColorVarWidget::~ColorVarWidget()
{
}


void ColorVarWidget::resetButtonColor()
{
    // set the button color to the passed-in color
    char stylesheet[255];
    sprintf( stylesheet, "background-color: #%02x%02x%02x", color.red(), color.green(), color.blue() );
    colorButton->setStyleSheet( QString(stylesheet) );
}


void ColorVarWidget::showColorChanger()
{
    if (!_colorDialog) {
        QWidget* mainWindow = qApp->topLevelWidgets().front();
        _colorDialog = new QColorDialog(mainWindow);
        _colorDialog->setOption(QColorDialog::NoButtons, true);
    }

    _colorDialog->disconnect();
    _colorDialog->setCurrentColor(color);
    _colorDialog->show();
    connect(_colorDialog, SIGNAL(currentColorChanged(const QColor&)), this, SLOT(setColor(const QColor&)));
}

void ColorVarWidget::setColor(const QColor& newcolor)
{
    color = newcolor;
    resetButtonColor();
    emit(valueChanged());
}

void ColorVarWidget::setToDefault()
{
    setColor(defaultColor);
}
